function showhid(id){
    document.getElementById(id).style.display ='block';
}
function showhid2(id){
    document.getElementById(id).style.display ='none';
}